# grid / :has + animated grid tracks (Safari only)

A Pen created on CodePen.

Original URL: [https://codepen.io/michellebarker/pen/vYpdEgQ](https://codepen.io/michellebarker/pen/vYpdEgQ).

Using GSAP to animate the grid tracks, because Safari doesn’t support this in CSS yet